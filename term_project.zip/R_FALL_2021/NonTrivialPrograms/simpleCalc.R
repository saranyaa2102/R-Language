# program to elaborate on input output using R language
# logic of the program is designing a simple calculator
# common input functions
# 1. readline()
# 2. scan()
# common output functions
# 1. print
# 2. cat

# add function
add <- function(a,b){
  x<- a+b
  return(x)
}

# subtract function
sub <- function(a,b){
  x<- a-b
  return(x)
}

# multiplication function
mul <- function(a,b){
  x<- a*b
  return(x)
}

# division function
div <- function(a,b){
  x<- a/b
  return(x)
}

# power function
pow <- function(a,b){
  x<- a^b
  return(x)
}


# print the details of the functionality
print("Select an operation from the list")
cat(1,"Add\n",2,"Subtract\n",3,"Multiply\n",4,"Divide\n",5,"Power")

5#Get a choice from the user
choice=as.integer(readline(prompt = "Enter choice [1/2/3/4/5]:"))
cat("Your Choice",choice)

number1 = as.integer(readline(prompt="Enter first number:"))
number2 = as.integer(readline(prompt="Enter second number:"))

print(typeof(number1))
print(length(number1))

print(typeof(number2))
print(length(number2))

operation <- switch(choice,"+","-","*","/","^")
answer<- switch(choice,add(number1,number2),sub(number1,number2),mul(number1,number2),
                div(number1,number2),pow(number1,number2))
print(paste(number1,operation,number2,"=",answer))

