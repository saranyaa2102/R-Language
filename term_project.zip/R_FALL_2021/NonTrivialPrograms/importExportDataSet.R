install.packages("readxl")
library(readxl)

dataSet1<-read_xlsx("C:/Users/ksriniv2/Downloads/CerealDataset.xlsx")
view(dataSet1)

dataSet2<-read.csv("C:/Users/ksriniv2/Downloads/addresses.csv")
view(dataSet2)

write.csv(dataSet2,"C:/Users/ksriniv2/Downloads/downloaded.csv")