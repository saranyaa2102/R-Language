# 2 important data structures in R programming
# Data Frame
# List
# Create Data Frame
stud.data <- data.frame(
    stud_id = c(1:4),
    stud_name = c("Alex","Bob","Caly","Dory"),
    grade = c("B","A","C","A"),
    birth_date = as.Date(c("1997-5-6","1995-2-7","2000-1-1","1996-11-15")),
    stringsAsFactors = FALSE
)
#Print the Data Frame
print(stud.data)

#Get the structure of the Data Frame
str(stud.data)

#Create List
list_data <- list("Survey of Programming Language", "Student Union", 50.9, TRUE)
print(list_data)

