# some important control structures in R
# if
# if ... else
# for
# while
# function to sort the array using bubble sort using 10 random numbers
bubbleSort <- function(arr)
{
  # calculate the length of array
  n <- length(arr)
  # run loop n-1 times
  for (i in 1 : (n - 1)) {
    # run loop (n-i) times
    for (j in 1 : (n - i)) {
      # compare elements
      if (arr[j] > arr[j + 1]) {
        temp <- arr[j]
        arr[j] <- arr[j + 1]
        arr[j + 1] <- temp
      }
    }
  }
  arr
}

# take 10 random numbers between 1 - 100
a <- sample(1:200,10)
cat("Random array generated\n",a)

# sort the array and store the result
# in sortedArray
sortedArray <- bubbleSort(a)

# print sorted_array
cat("\nSorted array\n",sortedArray)