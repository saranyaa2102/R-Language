All of the project are 
1. IO - simpleCalc.R
2. Data Structures - dataFrame.R
3. Control Structures - bubbleSort.R
4. Import Export - importExportDataSet.R
5. diabetesPrediction.R

NOTE:
The above R program files have been executed in R Studio with R version 4.1.1 (2021-08-10) 