#Installing the required packages
install.packages("mlbench")      # to access the dataset required for the predictive analysis
install.packages("caret")        #to create partitions for train and test data and develop models
install.packages("corrplot")     #to create correlation plots     
install.packages("pROC")        #to calculate the ROC values and create graphs
install.packages("caTools")     #to create AUC graphs
install.packages("tidyverse")    #to perform data manipulation

#Loading the above installed Packages

library(mlbench)
library(caret)
library(corrplot)
library(pROC)
library(caTools)
library(tidyverse)




#creation of dataframe
df<-PimaIndiansDiabetes

#view the dataframe
View(df)

#analyzing dimensions of dataframe
dim(df)

#check the levels of categorical variables in the dataframe (i.e. diabetes)
levels(df$diabetes)

#view the structure of dataframe
str(df)
head(df)


#replacing 0 values for the required attributes in the dataframe using the corresponding median values
#blood pressure attribute
df$pressure[df$pressure==0]=median(df$pressure[df$pressure>0])
df$pressure

#BMI attribute
df$mass[df$mass==0]=median(df$mass[df$mass>0])
df$mass

#glucose attribute
df$glucose[df$glucose==0]=median(df$glucose[df$glucose>0])
df$glucose

#insulin attribute
df$insulin[df$insulin==0]=median(df$insulin[df$insulin>0])
df$insulin

#splitting the data into train and test

partition <- caret::createDataPartition(y = df$diabetes, times = 1, p = 0.75, list = FALSE)

# create training data set
train_data <- df[partition,]

# create testing data set, subtracting the rows partition to get remaining 30% of the data
test_data <- df[-partition,]

str(train_data)
#Exploratory data analysis
summary(train_data)


ggplot(train_data, aes(diabetes, fill = diabetes)) + 
  geom_bar() +
  theme_bw() +
  labs(title = "Diabetes Classification", x = "Diabetes") +
  theme(plot.title = element_text(hjust = 0.5))

#Correlation matrix
cor_data <- cor(train_data[,setdiff(names(train_data), 'diabetes')])
cor_data
corrplot::corrplot(cor_data)

#----------------------------------------------------------------------------------------------
#Random forest model
#-----------------------------------------------------------------------------------------------
model_forest <- caret::train(diabetes ~., data = train_data,
                             method = "ranger",
                             metric = "ROC",
                             trControl = trainControl(method = "cv", number = 8,
                                                      classProbs = T, summaryFunction = twoClassSummary),
                             preProcess = c("center","scale","pca"))

model_forest

#Calculating the ROC value
model_forest$results[6,4]


#---------------------------------------------------------------------------------------------
# KNN Model
#---------------------------------------------------------------------------------------------
model_knn <- caret::train(diabetes ~., data = train_set,
                          method = "knn",
                          metric = "ROC",
                          tuneGrid = expand.grid(.k = c(3:10)),
                          trControl = trainControl(method = "cv", number = 10,
                                                   classProbs = T, summaryFunction = twoClassSummary),
                          preProcess = c("center","scale","pca"))

model_knn

#Calculating ROC value
model_knn$results[8,2]


#---------------------------------------------------------------------------------------------
#Logistic Regression
#---------------------------------------------------------------------------------------------
model_glm <- caret::train(diabetes ~., data = train_set,
                          method = "glm",
                          metric = "ROC",
                          tuneLength = 10,
                          trControl = trainControl(method = "cv", number = 10,
                                                   classProbs = T, summaryFunction = twoClassSummary),
                          preProcess = c("center","scale","pca"))

model_glm

#Calculating ROC Value
model_glm$results[2]


#---------------------------------------------------------------------------------------------
#XGBoost
#---------------------------------------------------------------------------------------------
xgb_grid_1  <-  expand.grid(
  nrounds = 50,
  eta = c(0.03),
  max_depth = 1,
  gamma = 0,
  colsample_bytree = 0.6,
  min_child_weight = 1,
  subsample = 0.5
)

model_xgb <- caret::train(diabetes ~., data = train_set,
                          method = "xgbTree",
                          metric = "ROC",
                          tuneGrid=xgb_grid_1,
                          trControl = trainControl(method = "cv", number = 10,
                                                   classProbs = T, summaryFunction = twoClassSummary),
                          preProcess = c("center","scale","pca"))
model_xgb

#Calculating ROC value
model_xgb$results["ROC"]




#---------------------------------------------------------------------------------------------
# Random Forest
#--------------------------------------------------------------------------------------------

# Prediction on Test data set
pred_rf <- predict(model_forest, test_set)
# Confusion Matrix 
cm_rf <- confusionMatrix(pred_rf, test_set$diabetes, positive="pos")

# Prediction Probabilities
pred_prob_rf <- predict(model_forest, test_set, type="prob")
# ROC value
roc_rf <- roc(test_set$diabetes, pred_prob_rf$pos)

# Confusion Matrix for Random Forest Model
cm_rf

#printing the roc value
roc_rf

#AUC curve
caTools::colAUC(pred_prob_rf$pos, test_set$diabetes, plotROC = T)

#---------------------------------------------------------------------------------------------
# XGBOOST - eXtreme Gradient BOOSTing 
#---------------------------------------------------------------------------------------------
# prediction on Test data set
pred_xgb <- predict(model_xgb, test_set)
# Confusion Matrix 
cm_xgb <- confusionMatrix(pred_xgb, test_set$diabetes, positive="pos")


# Prediction Probabilities
pred_prob_xgb <- predict(model_xgb, test_set, type="prob")
# ROC value
roc_xgb <- roc(test_set$diabetes, pred_prob_xgb$pos)

# Confusion matrix 
cm_xgb

roc_xgb

#AUC curve
caTools::colAUC(pred_prob_xgb$pos, test_set$diabetes, plotROC = T)

#---------------------------------------------------------------------------------------------
#KNN Model
#--------------------------------------------------------------------------------------------

# prediction on Test data set
pred_knn <- predict(model_knn, test_set)
# Confusion Matrix 
cm_knn <- confusionMatrix(pred_knn, test_set$diabetes, positive="pos")

# Prediction Probabilities
pred_prob_knn <- predict(model_knn, test_set, type="prob")
# ROC value
roc_knn <- roc(test_set$diabetes, pred_prob_knn$pos)

# Confusion matrix 
cm_knn
roc_knn
#AUC curve
caTools::colAUC(pred_prob_knn$pos, test_set$diabetes, plotROC = T)


#-----------------------------------------------------------------------------------------------
# Logistic Regression
#------------------------------------------------------------------------------------------------

# prediction on Test data set
pred_glm <- predict(model_glm, test_set)
# Confusion Matrix 
cm_glm <- confusionMatrix(pred_glm, test_set$diabetes, positive="pos")

# Prediction Probabilities
pred_prob_glm <- predict(model_glm, test_set, type="prob")
# ROC value
roc_glm <- roc(test_set$diabetes, pred_prob_glm$pos)

# Confusion matrix 
cm_glm
roc_glm

#AUC curve
caTools::colAUC(pred_prob_glm$pos, test_set$diabetes, plotROC = T)







result_rf <- c(cm_rf$byClass['Sensitivity'], cm_rf$byClass['Specificity'], cm_rf$byClass['Precision'], 
               cm_rf$byClass['Recall'], cm_rf$byClass['F1'], roc_rf$auc)

result_xgb <- c(cm_xgb$byClass['Sensitivity'], cm_xgb$byClass['Specificity'], cm_xgb$byClass['Precision'], 
                cm_xgb$byClass['Recall'], cm_xgb$byClass['F1'], roc_xgb$auc)

result_knn <- c(cm_knn$byClass['Sensitivity'], cm_knn$byClass['Specificity'], cm_knn$byClass['Precision'], 
                cm_knn$byClass['Recall'], cm_knn$byClass['F1'], roc_knn$auc)

result_glm <- c(cm_glm$byClass['Sensitivity'], cm_glm$byClass['Specificity'], cm_glm$byClass['Precision'], 
                cm_glm$byClass['Recall'], cm_glm$byClass['F1'], roc_glm$auc)




all_results <- data.frame(rbind(result_rf, result_xgb, result_knn, result_glm))
names(all_results) <- c("Sensitivity", "Specificity", "Precision", "Recall", "F1", "AUC")
all_results
